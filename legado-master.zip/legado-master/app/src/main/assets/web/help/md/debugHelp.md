# 书源调试

* 调试搜索>>输入关键字，如：
```
系统
```
* 调试发现>>输入发现URL，如：
```
月票榜::https://www.qidian.com/rank/yuepiao?page={{page}}
```
* 调试详情页>>输入详情页URL，如：
```
https://m.qidian.com/book/1015609210
```
* 调试目录页>>输入目录页URL，如：
```
++https://www.zhaishuyuan.com/read/30394
```
* 调试正文页>>输入正文页URL，如：
```
--https://www.zhaishuyuan.com/chapter/30394/20940996
```
