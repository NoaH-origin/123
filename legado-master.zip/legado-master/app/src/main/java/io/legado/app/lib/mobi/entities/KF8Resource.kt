package io.legado.app.lib.mobi.entities

data class KF8Resource(
    val resourceType: String,
    val id: Int,
    val type: String
)
