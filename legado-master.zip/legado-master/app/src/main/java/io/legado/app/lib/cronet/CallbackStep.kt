package io.legado.app.lib.cronet

enum class CallbackStep {
    ON_READ_COMPLETED,
    ON_SUCCESS,
    ON_FAILED,
    ON_CANCELED
}
