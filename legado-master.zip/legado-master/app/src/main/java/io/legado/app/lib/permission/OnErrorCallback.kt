package io.legado.app.lib.permission

interface OnErrorCallback {

    fun onError(e: Exception)

}