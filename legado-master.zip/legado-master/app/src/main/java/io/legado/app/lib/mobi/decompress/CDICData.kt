package io.legado.app.lib.mobi.decompress

class CDICEntry(
    var data: ByteArray,
    var decompressed: Boolean
)
