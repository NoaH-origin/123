package io.legado.app.lib.mobi.entities

data class IndexTag(
    val tagId: Int,
    val tagValues: List<Int>
)
