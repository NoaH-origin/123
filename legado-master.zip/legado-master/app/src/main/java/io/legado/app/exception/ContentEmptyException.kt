package io.legado.app.exception

/**
 * 内容为空
 */
class ContentEmptyException(msg: String) : NoStackTraceException(msg)