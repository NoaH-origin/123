package io.legado.app.lib.mobi.entities

data class KF8Pos(
    val fid: Int,
    val offset: Int
)
