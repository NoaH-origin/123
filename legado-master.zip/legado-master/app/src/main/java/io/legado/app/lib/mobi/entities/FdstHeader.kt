package io.legado.app.lib.mobi.entities

data class FdstHeader(
    val magic: String,
    val numEntries: Int
)
