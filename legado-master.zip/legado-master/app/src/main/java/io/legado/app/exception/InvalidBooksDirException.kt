package io.legado.app.exception

class InvalidBooksDirException(msg: String) : NoStackTraceException(msg)
