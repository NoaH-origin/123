package io.legado.app.lib.mobi.entities

data class Ptagx(
    val tag: Int,
    val tagValueCount: Int,
    val valueCount: Int?,
    val valueBytes: Int?
)
