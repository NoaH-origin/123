package io.legado.app.lib.permission

interface OnPermissionsGrantedCallback {

    fun onPermissionsGranted()

}
